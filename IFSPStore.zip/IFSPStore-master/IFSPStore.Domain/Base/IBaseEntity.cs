﻿
namespace IFSPStore.Domain.Base
{
    public interface IBaseEntity
    {
    }
}
