# 🛍️ IFSPStore
Sistema de Gerenciamento para Loja - Básico

Projeto desenvolvido na disciplina de Programação Orientada a Eventos utilizando metodologia de desing DDD.

#

Diagrama do Banco de Dados

![banco](https://github.com/user-attachments/assets/9ab69c5d-287f-4477-8c03-c835fa360466)

